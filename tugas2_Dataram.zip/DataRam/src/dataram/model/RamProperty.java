/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram.model;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class RamProperty {
    private StringProperty id;
    private StringProperty merk;
    private StringProperty jenis;
    private StringProperty tipe;
    private StringProperty kapasitas;
     private StringProperty tanggal_produksi;

    public RamProperty(String id, String merk, String jenis, String tipe, String kapasitas, String tanggal_produksi) {
        this.id = new SimpleStringProperty(id);
        this.merk = new SimpleStringProperty(merk);
        this.jenis = new SimpleStringProperty(jenis);
        this.tipe = new SimpleStringProperty(tipe);
        this.kapasitas = new SimpleStringProperty(kapasitas);
        this.tanggal_produksi = new SimpleStringProperty(tanggal_produksi);
    }
    public RamProperty(Ram rm){
        this.id = new SimpleStringProperty(rm.getId());
        this.merk = new SimpleStringProperty(rm.getMerk());
        this.jenis = new SimpleStringProperty(rm.getJenis());
        this.tipe = new SimpleStringProperty(rm.getTipe());
        this.kapasitas = new SimpleStringProperty(rm.getKapasitas());
        this.tanggal_produksi = new SimpleStringProperty(rm.tanggal_produksi());
    }
    public StringProperty getJenisProperty() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = new SimpleStringProperty(jenis);
    }

    public StringProperty getIdProperty() {
        return id;
    }

    public void setId(String id) {
        this.id = new SimpleStringProperty(id);
    }

    public StringProperty getMerkProperty() {
        return merk;
    }
      public void settipe(String tipe) {
        this.tipe = new SimpleStringProperty(tipe);
    }

    public StringProperty getKapasitasProperty() {
        return kapasitas;
    }

    public void setKapasitas(String kapasitas) {
        this.kapasitas = new SimpleStringProperty(kapasitas);
    }

    public StringProperty getTanggal_produksiProperty() {
        return tanggal_produksi;
    }


    public String getId() {
        return id.get();
    }

    public String getMerk() {
        return merk.get();
    }

    public String getJenis() {
        return jenis.get();
    }

    public String getTipe() {
        return tipe.get();
    }

    public String getKapasitas() {
        return kapasitas.get();
    }
    public String getTanggal_produksi() {
        return tanggal_produksi.get();
    }
    
}
