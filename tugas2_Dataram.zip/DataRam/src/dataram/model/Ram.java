/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram.model;


public class Ram {
    private String id;
    private String merk;
    private String jenis;
    private String tipe;
    private String kapasitas;
    private String tanggal_produksi;
    public Ram(String id, String merk, String jenis, String tipe, String kapasitas,String tanggal_produksi ) {
        this.id = id;
        this.merk = merk;
        this.jenis = jenis;
        this.tipe = tipe;
        this.kapasitas = kapasitas;
        this.tanggal_produksi = tanggal_produksi;
    }

    public Ram(String text, String text0, String toString, String tipe, String toString0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMerk() {
        return merk;
    }

    public void setmerek(String merek) {
        this.merk = merk;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getKapasitas() {
        return kapasitas;
    }

    public void setKapasitas(String kapasitas) {
        this.kapasitas = kapasitas;
    }
    
     public String getTanggal_produksi() {
        return tanggal_produksi;
    }

    public void setTanggal_produksi(String Tanggal_produksi) {
        this.tanggal_produksi = tanggal_produksi;
    }

    String tanggal_produksi() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
