/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram;

import dataram.model.RamProperty;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import dataram.db.DBHandler;
import dataram.model.RamProperty;



public class FXMLDataViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TableView<RamProperty> tblRam;

    @FXML
    private TableColumn<RamProperty, String> colId;

    @FXML
    private TableColumn<RamProperty, String> colMerk;

    @FXML
    private TableColumn<RamProperty, String> colJenis;

    @FXML
    private TableColumn<RamProperty, String> colTipe;

    @FXML
    private TableColumn<RamProperty, String> colKapasitas;

    @FXML
    private TableColumn<RamProperty, String> colTanggal_produksi;

    @FXML
    private MenuItem menuAddData;

    @FXML
    private MenuItem menuDeleteData;

    @FXML
    void viewAddDataForm(ActionEvent event) throws IOException {
        Stage modal = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDataView.fxml"));
        Scene scene = new Scene(root);
        modal.setScene(scene);
//        modal.initOwner(((Node)event.getSource()).getScene().getWindow() );
        modal.initModality(Modality.APPLICATION_MODAL);
        modal.showAndWait();
    }

    @FXML
    void deleteDataMahasiswa(ActionEvent event) {
        RamProperty rm = tblRam.getSelectionModel().getSelectedItem();
        DBHandler dh = new DBHandler("MYSQL");
        dh.deleteDataram(rm);
        showDataRam();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showDataRam();

        tblRam.getSelectionModel().selectedIndexProperty().addListener(listener -> {
//            JOptionPane.showMessageDialog(null, "Table Diklik!");
            menuDeleteData.setDisable(false);
        });
    }

    public void showDataRam() {
        DBHandler dh = new DBHandler("MYSQL");
        ObservableList<RamProperty> data = dh.Ram();
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colMerk.setCellValueFactory(new PropertyValueFactory<>("merk"));
        colJenis.setCellValueFactory(new PropertyValueFactory<>("jenis"));
        colTipe.setCellValueFactory(new PropertyValueFactory<>("tipe"));
        colKapasitas.setCellValueFactory(new PropertyValueFactory<>("kapasitas"));
        colTanggal_produksi.setCellValueFactory(new PropertyValueFactory<>("tanggal_produksi"));
        tblRam.setItems(null);
        tblRam.setItems(data);
    }
}
