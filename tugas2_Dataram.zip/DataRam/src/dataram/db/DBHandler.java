/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram.db;
import dataram.model.RamProperty;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import dataram.model.Ram;
import javafx.collections.ObservableList;

public class DBHandler {
    public final Connection conn;

    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addRam(Ram rm){
        String insertrm = "INSERT INTO `ram`(`id`, `merk`, `jenis`,`tipe`,`kapasitas`,`tanggal_produksi`)"
                + "VALUES (?,?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertrm);
            stmtInsert.setString(1, rm.getId());
            stmtInsert.setString(2, rm.getMerk());
            stmtInsert.setString(3, rm.getJenis());
            stmtInsert.setString(4, rm.getTipe());
            stmtInsert.setString(5, rm.getKapasitas());
            stmtInsert.setString(5, rm.getTanggal_produksi());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteDataram(RamProperty rm) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ObservableList<RamProperty> Ram() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
