/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram;

import dataram.db.DBHandler;
import dataram.model.Ram;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 *
 * @author USER
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private Button btsave;

    @FXML
    private ComboBox<?> cbjenis;

    @FXML
    private DatePicker dptanggal;

    @FXML
    private Label label;

    @FXML
    private RadioButton rdddr2;
    
    @FXML
    private RadioButton rdddr3; 
    
    @FXML
    private RadioButton rdddr4;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfmerk;
    
    @FXML
    private TextField tfkapasitas;
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
       System.out.println("You clicked me!");
       System.out.println(tfid.getText());
        System.out.println(tfmerk.getText());
        System.out.println(dptanggal.getValue().toString());
        String tipe="";
        if (rdddr2.isSelected())
           tipe=rdddr2.getText();
        if (rdddr3.isSelected())
           tipe=rdddr3.getText();
         if (rdddr4.isSelected())
           tipe=rdddr4.getText();
        
        System.out.println(tipe);
        System.out.println(cbjenis.getValue().toString());

        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODOz
      
    }    

    private static class Button {

        public Button() {
        }
    }

    private static class ComboBox<T> {

        public ComboBox() {
        }

        private Object getValue() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setItems(ObservableList items) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class TextField {

        public TextField() {
        }

        private boolean getText() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class RadioButton {

        public RadioButton() {
        }

        private boolean isSelected() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private String getText() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

    private static class DatePicker {

        public DatePicker() {
        }

        private Object getValue() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
}
